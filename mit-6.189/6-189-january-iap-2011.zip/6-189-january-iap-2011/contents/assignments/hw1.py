# Name:
# Section: 
# Date:
# hw1.py

##### Template for Homework 1, exercises 1.2-1.5 ######

print "********** Exercise 1.2 **********"

# Do your work for Exercise 1.2 here

print "Not implemented" # Delete this line when you write your code!


print "********** Exercise 1.3 **********"

# Do your work for Excercise 1.3 here. Hint - how many different
# variables will you need?

print "Not implemented" # Delete this line when you write your code!


print "********** Exercise 1.4 **********"
print "********* Part II *************"

print "Not implemented" # Delete this line when you write your code!

print "********* Part III *************"

print "Not implemented" # Delete this line when you write your code!


print "********** Exercise 1.5 **********"

print "Not implemented" # Delete this line when you write your code!
